package springmvc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import springmvc.model.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	private JdbcTemplate jdbcTemplate;

	public EmployeeDaoImpl(DataSource dataSoruce) {
		jdbcTemplate = new JdbcTemplate(dataSoruce);
	}

	public int create(Employee employee) {

		String sql = "insert into employee1(name,designation,empid) values(?,?,?)";

		try {

			int counter = jdbcTemplate.update(sql,
					new Object[] { employee.getName(), employee.getDesignation(), employee.getEmpid() });

			return counter;

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	public List<Employee> read() {
		List<Employee> employeeList = jdbcTemplate.query("SELECT * FROM EMPLOYEE1", new RowMapper<Employee>() {

			public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
				Employee employee = new Employee();

				employee.setId(rs.getInt("id"));
				employee.setName(rs.getString("name"));
				employee.setDesignation(rs.getString("designation"));
				employee.setEmpid(rs.getString("empid"));

				return employee;
			}

		});

		return employeeList;
	}

	
	public List<Employee> findEmployeeById(int employeeId) {

		List<Employee> employeeList = jdbcTemplate.query("SELECT * FROM EMPLOYEE1 where id=?",
				new Object[] { employeeId }, new RowMapper<Employee>() {

				
					public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
						Employee employee = new Employee();

						employee.setId(rs.getInt("id"));
						employee.setName(rs.getString("name"));
						employee.setDesignation(rs.getString("designation"));
						employee.setEmpid(rs.getString("empid"));

						return employee;
					}

				});

		return employeeList;
	}


	public int update(Employee employee) {
		String sql = "update  employee1 set name=?, designation=?, empid=? where id=?";

		try {

			int counter = jdbcTemplate.update(sql,
					new Object[] { employee.getName(), employee.getDesignation(), employee.getEmpid(), employee.getId() });

			return counter;

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	public int delete(int employeeId) {
		String sql = "delete from employee1 where id=?";

		try {

			int counter = jdbcTemplate.update(sql, new Object[] { employeeId });

			return counter;

		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

}
