package springmvc.dao;

import java.util.List;

import springmvc.model.Employee;

public interface EmployeeDao {

	public int create(Employee employee);

	public List<Employee> read();

	public List<Employee> findEmployeeById(int employeeId);

	public int update(Employee employee);

	public int delete(int employeeId);

}
